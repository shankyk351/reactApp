import React, { Component } from 'react';

import Cleaning from './../services/cleaning';
import Washing from './../services/washing';
import Laundry from './../services/laundry';
import Mopping from './../services/mopping';

class Service extends Component {
    

    constructor(){
        super();
        this.state = {
            defaultData: ''
        }
    }


    parentData(e){
        console.log(e.target.value);
        this.setState({
            defaultData: e.target.value
        })
    }


    render() { 
        return ( 
            <div className="staticPage">
                <h3 className="pageTitle">{this.props.title}</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

                <div className="form-group">
                    <label>Data:</label>
                    <input type="text" className="form-control" defaultValue={this.state.defaultData} onKeyUp={(e)=>this.parentData(e)}/>
                </div>
                <div className="container">
                    <div className="row">
                        <div className="col-md-6">
                            <div className="service-container">
                               <Cleaning parentData={this.state.defaultData} />
                            </div>
                        </div>
                        <div className="col-md-6">
                            <div className="service-container">
                                <Mopping parentData={this.state.defaultData}/>
                            </div>
                        </div>
                        <div className="col-md-6">
                            <div className="service-container">
                                <Washing parentData={this.state.defaultData}/>
                            </div>
                        </div>
                        <div className="col-md-6">
                            <div className="service-container">
                                <Laundry parentData={this.state.defaultData} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
         );
    }
}
 

Service.defaultProps = {
    title: 'Service page!!!'
}
export default Service;