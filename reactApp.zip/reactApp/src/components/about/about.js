import React, { Component } from 'react';

import Userdata from './../userdata/userdata';

class About extends Component {
    render() { 
        return ( 
            <div className="staticPage">
                <h3 className="pageTitle">{this.props.title}</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                <div className="createUser">
                    <div className="createUserForm">
                        <h3>Add User</h3>
                        <form>
                            <div className="row">
                                <div className="col-md-4">
                                    <div className="form-group">
                                        <label>Name</label>
                                        <input type="text" className="form-control"/>
                                    </div>
                                </div>
                                <div className="col-md-4">
                                    <div className="form-group">
                                        <label>Mobile</label>
                                        <input type="number" className="form-control"/>
                                    </div>
                                </div>
                                <div className="col-md-4">
                                    <div className="form-group">
                                        <label>Email</label>
                                        <input type="email" className="form-control"/>
                                    </div>
                                </div>
                                <div className="col-md-6">
                                
                                </div>
                            </div>
                            <div className="form-group">
                                <label>Address</label>
                                <textarea name="" className="form-control" rows="4"></textarea>
                            </div>
                            <button className="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
                <Userdata />
            </div>
         );
    }
}

About.defaultProps = {
    title: 'About page!!!'
}

export default About;