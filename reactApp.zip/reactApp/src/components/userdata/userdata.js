import React, { Component } from 'react';

class Userdata extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            userData: []
         }
    }
   

    componentDidMount(){
        const staticData = [
            {name: 'himanshu', mobile: 1234567897, email: 'himanshu@yopmail.com', address: 'uttam nagar'},
            {name: 'priyanka', mobile: 9874563121, email: 'priyanka@yopmail.com', address: 'indirapuram'},
            {name: 'gargi', mobile: 9546871232, email: 'gargi@yopmail.com', address: 'gaur city noida'},
            {name: 'prasanna', mobile: 9875463214, email: 'prasanna@yopmail.com', address: 'grater noida'},
            {name: 'sunil', mobile: 6548793215, email: 'sunil@yopmail.com', address: 'shipra, indirapuram'}
        ]

        this.setState({
            userData: staticData
        })
    }
    delete(e,index) {
        var currentData = this.state.userData.splice(index, 1);        
        this.setState({ 
            userData: this.state.userData
        })

    }
    render() { 
       
        return ( 
            <div>
                <table className="table table-bordered table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Mobile</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                            {this.state.userData.map((el, index)=>{
                                return<tr  key={index}>
                                    <td >{el.name}</td>
                                    <td>{el.mobile}</td>
                                    <td>{el.email}</td>
                                    <td>{el.address}</td>
                                    <td>
                                        <div className="btn-group">
                                            <button className="btn btn-sm btn-default">Edit</button>
                                            <button onClick={e=>this.delete(e, index)} className="btn btn-sm btn-default">Delete</button>
                                        </div>
                                    </td>
                                </tr>
                            })}
                    </tbody>
                </table>
            </div>
         );
    }
}
 
export default Userdata;