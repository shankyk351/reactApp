import React, {Component} from 'react';

import './../assets/sass/main.scss';
// using ES6 modules
import { Route, NavLink, HashRouter } from "react-router-dom";

import Navs from './nav/Nav';

class App extends Component{
    constructor(){
        super();
        this.state = {
            allPages: {
                home: 'Home',
                about: 'About Us',
                service: 'Service',
                posts: 'Posts',
                contact: 'Contact Us'
            }
        }
    }
    render(){
        return(
            <div className="app">
                <div className="container">
                    <Navs pageName={this.state.allPages} />
                </div>
            </div> 
        );
    }
}

export default App;