import React, { Component } from 'react';



class Home extends Component {

    constructor(){
        super();

        this.state = {
            data: '',
            list:  []
        }
    }

    componentWillMount(){

    }

    componentDidMount(){
        let staticJSON = {
            data: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
            list:  ['Lorem Ipsum', 'Lorem Ipsum', 'Lorem Ipsum', 'Lorem Ipsum', 'Lorem Ipsum',]
        }

        this.setState({
            data: staticJSON.data,
            list: staticJSON.list
        })

        // fetch('https://jsonplaceholder.typicode.com/posts',{method: 'GET'})
        // .then(response => response.json())
        // .then(data=>{
        //     console.log('data', data);
        // })
    }

    render() { 
        return ( 
            <div className="staticPage">
                <h3 className="pageTitle">{this.props.title}</h3>
                <p>{this.state.data}</p>
                <ul>
                    {this.state.list.map((el, index)=>{
                        return <li key={index}>{el}</li>
                    })}
                </ul>
                <p>{this.state.data}</p>
            </div>
         );
    }
}

Home.defaultProps = {
    title: 'Home Page!!!'
}
 
export default Home;