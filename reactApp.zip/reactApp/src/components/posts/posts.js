import React, { Component } from 'react';

import { httpModule } from '../../services/http';

let _isMounted = false;

class Posts extends Component {
    
    constructor(props) {
        super(props);
        this.state = { 
            postData : []
         }
    }

    componentDidMount(){
        this._isMounted = true;

        fetch('https://jsonplaceholder.typicode.com/posts',{type: 'GET'})
        .then(response => response.json())
        .then(data => {
            console.log('data', data);
            if (this._isMounted){
                this.setState({
                    postData: data
                })
            }
        })
    }

    componentWillUnmount() {
        this._isMounted = false;
    }

    render() { 
        return ( 
            <div>
                <div className="staticPage">
                    {this.state.postData.map((data, index)=>{
                        return <div className="posts-container" key={index}>
                            <h5>{index + 1} {data.title}</h5>
                            <p>{data.body}</p>
                        </div>
                    })}
                </div>
            </div>
         );
    }
}
 
export default Posts;