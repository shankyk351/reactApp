import React, {Component} from 'react';

// using ES6 modules
import { Route, NavLink, HashRouter } from "react-router-dom";

import Home from './../home/home';
import About from './../about/about';
import Service from './../service/service';
import Posts from './../posts/posts';
import Contact from './../contact/contact';

export class Navs extends Component{
    constructor(props){
        super(props);
    }
    render(){
        return(
            <HashRouter>
                <div className="topNav">
                    <ul className="nav-list justify-content-center">
                        <li><NavLink to="/home/">{this.props.pageName.home}</NavLink></li>
                        <li><NavLink to="/about/">{this.props.pageName.about}</NavLink></li>
                        <li><NavLink to="/service/">{this.props.pageName.service}</NavLink></li>
                        <li><NavLink to="/posts/">{this.props.pageName.posts}</NavLink></li>
                        <li><NavLink to="/contact/">{this.props.pageName.contact}</NavLink></li>
                    </ul>
                    <Route path="/" exact strict component={Home} />
                    <Route path="/home/" component={Home} />
                    <Route path="/about/" component={About} />
                    <Route path="/service/" component={Service} />
                    <Route path="/posts/" component={Posts} />
                    <Route path="/contact/" component={Contact} />
                </div>
            </HashRouter>
        )
    }
}

export default Navs;