import React, { Component } from 'react';

class Washing extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( 
            <div>
                <h3>Washing</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium excepturi natus quaerat dignissimos eum, officiis, delectus unde porro corrupti autem modi minus facilis rerum, omnis quo enim! Blanditiis, repudiandae officia.</p>
                <p>{this.props.parentData}</p>
                <button className="btn btn-primary">More Info</button>
            </div>
         );
    }
}
 
export default Washing;