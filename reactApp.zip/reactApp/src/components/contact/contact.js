import React, { Component } from 'react';

class Contact extends Component {

    constructor(props){
        super(props);
        this.state = {
            email: 'john@doe.com',
            password: '',
            isChecked: false,
            emailError: '',
            emailPatternError: '',
            passwordError: '',
            formValid: false
        }

        this.updateEmail = this.updateEmail.bind(this);
        this.updatePassword = this.updatePassword.bind(this);
        this.submitForm = this.submitForm.bind(this);
    }
    updateEmail(e){
        this.setState({
            email: e.target.value
        });
    }

    updatePassword(e){
        this.setState({
            password: e.target.value
        });
    }

    submitForm(e){

        var emailPattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        

        if(!this.state.email || !this.state.password || !this.state.email.match(emailPattern)){
            this.setState(
                {
                    formValid: false
                }
            )
        }else{
            this.setState(
                {
                    formValid: true
                }
            )
        }

        if(!this.state.formValid){

            if(!this.state.email){
                this.setState({
                    emailError: 'Email is required'
                })
            }
            
            if(!this.state.password){
                this.setState({
                    passwordError: 'Password is required'
                })
            }

            if(!this.state.email.match(emailPattern)){
                this.setState({
                    emailPatternError: 'Invalid Email'
                })
            }
        }
        else{
            let outputJSON = {
                email: this.state.email,
                password: this.state.password,
                isChecked: this.state.isChecked
            }
    
            console.log('output JSON', outputJSON);
        }
        
        return false;
        
    }

    checkMe(e){
        console.log('check value', e.target.value);
        this.setState({
            isChecked: e.target.checked
        })
    }

    render() { 
        return ( 
            <div className="staticPage">
                <h3 className="pageTitle">{this.props.title}</h3>
                <form onSubmit={this.submitForm} noValidate>
                    <div className="form-group">
                        <label>Email address</label>
                        <input type="email" className="form-control" defaultValue={this.state.email} onKeyUp={this.updateEmail} placeholder="Enter email" />
                        <small className="form-text text-muted">{this.state.email}</small>
                        <small className="form-text text-danger">{this.state.emailError}</small>
                        <small className="form-text text-danger">{this.state.emailPatternError}</small>
                        {/* <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone else.</small> */}
                    </div>

                    <div className="form-group">
                        <label>Password</label>
                        <input type="password" className="form-control" onKeyUp={this.updatePassword} placeholder="Password" />
                        <small className="form-text text-danger">{this.state.passwordError}</small>
                    </div>
                    <div className="form-check">
                        <input type="checkbox" onChange={e => this.checkMe(e)} className="form-check-input" id="exampleCheck1" />
                        <label className="form-check-label">Check me out</label>
                    </div>
                    
                    <button type="submit" className="btn btn-primary mt-3">Submit</button>
                </form>
            </div>
         );
    }
}

Contact.defaultProps = {
    title: 'Contact Page!!!'
}
 
export default Contact;