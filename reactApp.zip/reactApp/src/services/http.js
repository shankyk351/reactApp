export const httpModule = {
    http: function(type, url, data={}){
        let responseData;
        if(type == 'GET'){
            let promise = new Promise(function(resolve, reject){
                fetch(url, { type: 'GET' })
                    .then(response => response.json())
                    .then(data => {
                        promise.resolve(data);
                    })
            })
            
        }else if(type == 'POST'){
            fetch(url, {type: 'POST', body: data})
            .then(response => response.json())
            .then(data=>{
                responseData = data
                return responseData;
            })
        }
    }
}