// import React from 'react';
// import ReactDom from 'react-dom';
// import App from './src/components/App.js';

// ReactDom.render(<App />, document.getElementById('app'));

import { createStore, combineReducers } from 'redux';

const mathReducer = (state, action)=>{
    switch(action.type){
        case 'ADD':
            state = state + action.payload;
            break;
        case 'SUBTRACT':
            state = state - action.payload;
            break;
        case 'MULTIPLY':
            state = state * action.payload;
            break;
        case 'DIVIDE':
            state = state/action.payload;
            break;
    }
        return state;
}

const userReducer = (state = {
    payload: 1
}, action ) => {
    switch (action.type) {
        case 'SET_NAME':
            state.payload = state.payload + action.payload;
            break;
        case 'SET_PHONE':
            state.payload = state.payload - action.payload;
            break;
    }
    return state;
}

const store = createStore(mathReducer);

store.subscribe(()=>{
    console.log('Store updated : ', store.getState());
})

store.dispatch({
    type: 'ADD',
    payload: 15
})

store.dispatch({
    type: 'SUBTRACT',
    payload: 6
})